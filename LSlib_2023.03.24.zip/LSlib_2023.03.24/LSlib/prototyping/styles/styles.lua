
if LSlib then
  if not LSlib.styles then LSlib.styles = {}

    require "styles-frame"
    require "styles-flow"
    require "styles-button"
    require "styles-label"
    require "styles-image"
    require "styles-table"

    require "styles-filler"
    require "styles-tab"

  end
end
