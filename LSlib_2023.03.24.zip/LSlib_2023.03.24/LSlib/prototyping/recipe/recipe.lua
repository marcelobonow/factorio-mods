
if LSlib then
  if not LSlib.recipe then LSlib.recipe = {}

    require "recipe-creation"
    require "recipe-properties"
    require "recipe-icons"
    require "recipe-module"

    require "recipe-ingredient"
    require "recipe-result"

  end
end
