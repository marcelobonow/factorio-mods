
if LSlib then
  if not LSlib.item then LSlib.item = {}

    require "item-creation"
    require "item-properties"
    require "item-module"
    require "item-icons"

  end
end
