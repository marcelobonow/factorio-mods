
if LSlib then
  if not LSlib.technology then LSlib.technology = {}

    require "technology-properties"
    require "technology-icons"

    require "technology-prerequisite"
    require "technology-ingredient"
    require "technology-effect"

  end
end
