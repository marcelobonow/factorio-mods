
if LSlib then

  require "item/item"
  require "entity/entity"
  require "recipe/recipe"
  require "technology/technology"

  require "styles/styles"

end
