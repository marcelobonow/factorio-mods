
if LSlib then
  if not LSlib.utils then LSlib.utils = {}

    require "utils-directions"
    require "utils-log"
    require "utils-shapes"
    require "utils-string"
    require "utils-table"
    require "utils-units"

  end
end
