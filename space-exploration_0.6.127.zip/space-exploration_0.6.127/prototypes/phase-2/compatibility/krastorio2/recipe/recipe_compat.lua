local path = "prototypes/phase-2/compatibility/krastorio2/recipe/"

require(path .. "migration-dummies")
require(path .. "science")
require(path .. "military")
require(path .. "logistics")
require(path .. "matter")
require(path .. "landfill")
require(path .. "power")
require(path .. "resources")

require(path .. "recipe_ordering")
