local path = "prototypes/phase-3/compatibility/krastorio2/recipe/"

require(path .. "equipment")
require(path .. "modules")
require(path .. "intermediates")