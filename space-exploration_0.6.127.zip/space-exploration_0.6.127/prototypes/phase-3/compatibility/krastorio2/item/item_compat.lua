local path = "prototypes/phase-3/compatibility/krastorio2/item/"


require(path .. "item_ordering")