local data_util = require("data_util")

-- Advanced Pickaxe Research
data_util.tech_remove_ingredients("kr-advanced-pickaxe",{"matter-tech-card"})
data_util.tech_add_ingredients("kr-advanced-pickaxe",{"kr-optimization-tech-card"})