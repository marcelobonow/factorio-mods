local data_util = require("data_util")

data_util.tech_remove_ingredients("kr-optimization-tech-card",{"utility-science-pack"})