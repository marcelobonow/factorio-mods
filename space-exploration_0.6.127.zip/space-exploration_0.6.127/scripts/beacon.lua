local Beacon = {}

-- Note: supply_area_distance -- extends from edge of collision box
Beacon.affected_types = {"assembling-machine", "furnace", "lab", "mining-drill", "rocket-silo"}
Beacon.affected_types_lookup = core_util.list_to_map(Beacon.affected_types)

return Beacon
