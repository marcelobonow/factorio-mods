--- @deprecated use `gui` or `gui-lite` instead.`
return require("__flib__.gui")
