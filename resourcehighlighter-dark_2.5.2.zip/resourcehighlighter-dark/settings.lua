data:extend({
    {
		type = "bool-setting",
		name = "resourcehighlighter-highlight-all",
		default_value = false,
		setting_type = "runtime-global",
	},
    {
		type = "bool-setting",
		name = "resourcehighlighter-show-miners",
		default_value = false,
		setting_type = "runtime-global",
	},
    {
		type = "bool-setting",
		name = "resourcehighlighter-show-resource-results",
		default_value = false,
		setting_type = "runtime-global",
	},
    {
		type = "bool-setting",
		name = "resourcehighlighter-remember-selection",
		default_value = false,
		setting_type = "runtime-global",
    },
})
