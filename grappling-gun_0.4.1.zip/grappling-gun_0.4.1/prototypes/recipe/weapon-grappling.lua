local data_util = require("data_util")

data:extend({
  {
    type = "recipe",
    name = data_util.mod_prefix .. "grappling-gun",
    enabled = false,
    energy_required = 10,
    ingredients = {
      {type = "item", name = "steel-plate", amount = 10},
      {type = "item", name = "iron-gear-wheel", amount = 10},
      {type = "item", name = "pipe", amount = 5},
    },
    results = {
      {type = "item", name = data_util.mod_prefix .. "grappling-gun", amount = 1},
    },
    requester_paste_multiplier = 1,
  },
  {
    type = "recipe",
    name = data_util.mod_prefix .. "grappling-gun-ammo",
    enabled = false,
    energy_required = 1,
    ingredients = {
      {type = "item", name = "iron-stick", amount = 4 },
      {type = "item", name = "coal", amount = 2 },
    },
    results = {
      {type = "item", name = data_util.mod_prefix .. "grappling-gun-ammo", amount = 1}
    },
    requester_paste_multiplier = 1,
  },
})
