Grapple = {}

-- constants
Grapple.range = 40
Grapple.throw_speed = 1.6
Grapple.pull_speed = 0.8
Grapple.pull_speed_per_tick = 0.01 -- increase pull speed over time (for longer distances)
Grapple.max_orientation_delta_before_disconnect = 0.01 -- In "orientation" e.g. full circle is 1

function Grapple.destroy(tick_task)
  tick_task.valid = false
  if tick_task.character and tick_task.character.valid then
    tick_task.character.destructible = true
  end
  if tick_task.projectile and tick_task.projectile.valid then
    tick_task.projectile.surface.create_trivial_smoke{name="smoke", position = tick_task.projectile.position}
    tick_task.projectile.destroy()
  end
end

local function position_is_space(surface, position)
  local tile = surface.get_tile(position)
  return tile ~= nil and tile.name == "se-space"
end

local function draw_line(from, to)
  rendering.draw_line{
    color = {r=50,g=50,b=50,a=1},
    width = 2,
    gap_length = 0.1,
    dash_length = 0.1,
    from = from,
    from_offset = {0, -1},
    to = to,
    to_offset = {0, -1},
    surface = from.surface
  }
  rendering.draw_line{
    color = {r=0,g=0,b=0,a=1},
    width = 1,
    from = from,
    from_offset = {0, -1},
    to = to,
    to_offset = {0, -1},
    surface = from.surface
  }
end

local function is_jetpacking(character)
  if remote.interfaces["jetpack"] and remote.interfaces["jetpack"]["is_jetpacking"] then
    return remote.call("jetpack", "is_jetpacking", {character = character})
  else
    return false
  end
end

local function get_jetpack_velocity(character)
  if remote.interfaces["jetpack"] and remote.interfaces["jetpack"]["get_jetpack_for_character"] then
    local jetpack = remote.call("jetpack", "get_jetpack_for_character", {character = character})
    return jetpack and jetpack.velocity or nil
  else
    return nil
  end
end

local function set_jetpack_velocity(character, velocity)
  if remote.interfaces["jetpack"] and remote.interfaces["jetpack"]["set_velocity"] then
    remote.call("jetpack", "set_velocity", {unit_number = character.unit_number, velocity = velocity})
  end
end


function Grapple.get_pull_speed(tick_task)
  return Grapple.pull_speed + (game.tick - tick_task.tick) * Grapple.pull_speed_per_tick
end


function Grapple.attempt_cancel_grapple(event)
  if not storage.tick_tasks then return end
  local character = game.players[event.player_index].character
  if not character then return end
  local gun_inventory = character.get_inventory(defines.inventory.character_guns)
  if not gun_inventory then return end
  local selected_gun = gun_inventory[character.selected_gun_index]
  if selected_gun.valid_for_read and selected_gun.name ~= "grappling-gun" then return end

   for _, tick_task in pairs(storage.tick_tasks) do
    if tick_task.type == "grappling-gun" and tick_task.character == character then
      -- Grappling hook is already out, cancel this one
      if tick_task.pull then
        local last_orientation = tick_task.last_orientation or Util.vector_to_orientation(Util.vectors_delta(tick_task.character.position, tick_task.target_position))
        local pull_speed = Grapple.get_pull_speed(tick_task)
        local velocity = Util.orientation_to_vector(last_orientation, pull_speed)
        set_jetpack_velocity(tick_task.character, velocity)
      end
      Grapple.destroy(tick_task)
      return
    end
  end
end
script.on_event("shoot-enemy", Grapple.attempt_cancel_grapple)
script.on_event("shoot-selected", Grapple.attempt_cancel_grapple)

function Grapple.on_trigger_created_entity(event)
  if event.entity.name == "grappling-gun-trigger" and event.source and event.source.valid then
    -- If a grappling gun already exists, it will be cancelled in Grapple.attempt_cancel_grapple

    local tick_task = new_tick_task("grappling-gun")
    tick_task.surface = event.entity.surface
    tick_task.character = event.source
    tick_task.instigator_force = event.source.force

    local vector = util.vectors_delta(event.source.position, event.entity.position)
    if Util.vector_length(vector) > Grapple.range then
      vector = Util.vector_set_length(vector, Grapple.range)
    end
    local jetpack_velocity = get_jetpack_velocity(tick_task.character)
    local throw_speed = Grapple.throw_speed

    if jetpack_velocity then -- Carry momentum into the shot
      local old_vector_length = Util.vector_length(vector)

      -- Technically this should be recursive until it stops changing, but doing it just twice is good enough.
      local ticks_to_hit_target = math.ceil(old_vector_length / Grapple.throw_speed)
      ticks_to_hit_target = math.ceil(old_vector_length / (Grapple.throw_speed + Grapple.pull_speed_per_tick * ticks_to_hit_target))

      local vector_jetpack_moved_until_hit = Util.vector_multiply(jetpack_velocity, ticks_to_hit_target)
      vector = Util.vectors_add(vector, vector_jetpack_moved_until_hit)
      throw_speed = Grapple.throw_speed * (Util.vector_length(vector) / old_vector_length) -- Adjust throw speed so that we hit the target in the same time as before
    end

    local target_position = Util.vectors_add(event.source.position, vector)
    local safe_position = tick_task.surface.find_non_colliding_position (
      "grappling-gun-player-collision", target_position, Grapple.range / 4, 1, true
    )
    tick_task.target_position = safe_position or target_position
    tick_task.safe_position = safe_position -- may be nil
    tick_task.throw_speed = throw_speed
    local target_is_space = position_is_space(tick_task.surface, tick_task.target_position)
    local projectile_name = target_is_space and "grappling-gun-projectile-with-drone" or "grappling-gun-projectile"
    tick_task.target_is_space = target_is_space
    tick_task.projectile = tick_task.surface.create_entity{
      name = projectile_name,
      position = event.source.position,
      target = Util.vectors_add(tick_task.target_position, vector), -- aim further away
      speed = 0,
    }
    draw_line(tick_task.projectile, tick_task.character)
  end
end
Event.addListener(defines.events.on_trigger_created_entity, Grapple.on_trigger_created_entity)

function Grapple.tick_task_grappling_gun(tick_task)
  if tick_task.projectile and tick_task.projectile.valid and tick_task.character and tick_task.character.valid
    and tick_task.projectile.surface == tick_task.character.surface then

    if tick_task.pull then
      if tick_task.character.stickers then
        for _, sticker in pairs(tick_task.character.stickers) do sticker.destroy() end
      end
      if not tick_task.tick then tick_task.tick = game.tick end
      local pull_speed = Grapple.get_pull_speed(tick_task)
      local last_length = tick_task.last_length or Util.vectors_delta_length(tick_task.character.position, tick_task.target_position)
      local last_orientation = tick_task.last_orientation or Util.vector_to_orientation(Util.vectors_delta(tick_task.character.position, tick_task.target_position))

      local char_is_jetpacking = is_jetpacking(tick_task.character)
      local line_vector = Util.vectors_delta(tick_task.safe_position, tick_task.character.position)
      local new_vector = Util.vector_set_length(line_vector, last_length - pull_speed)
      local new_position = Util.vectors_add(tick_task.safe_position, new_vector)
      local new_orientation = Util.vector_to_orientation(Util.vectors_delta(new_position, tick_task.target_position))

      if (not char_is_jetpacking) and last_length <= pull_speed then
        -- Grapple end, no swing
        tick_task.character.teleport(tick_task.safe_position)
        Grapple.destroy(tick_task)
      elseif char_is_jetpacking and (last_length <= pull_speed or Util.orientation_delta(last_orientation, new_orientation) > Grapple.max_orientation_delta_before_disconnect) then
        -- Grapple end, swing
        local velocity = Util.orientation_to_vector(last_orientation, pull_speed)
        set_jetpack_velocity(tick_task.character, velocity)
        Grapple.destroy(tick_task)
      else
        -- Grapple pull
        tick_task.character.teleport(new_position)
        tick_task.last_length = last_length - pull_speed
        tick_task.last_orientation = new_orientation
        if not tick_task.character.valid then return Grapple.destroy(tick_task) end -- movement can cause invalid
      end

    else -- Grapple shooting forward
      tick_task.projectile.teleport(Util.move_to(tick_task.projectile.position, tick_task.target_position, tick_task.throw_speed))
      tick_task.projectile.surface.create_trivial_smoke{name="light-smoke", position = Util.vectors_add(tick_task.projectile.position,{x=0,y=-1})}
      if not tick_task.character.valid then return  Grapple.destroy(tick_task) end -- movement can cause invalid
      if Util.vectors_delta_length(tick_task.projectile.position, tick_task.target_position) < 0.01 then
        if tick_task.safe_position then
          tick_task.pull = true
          tick_task.character.destructible = false
          local last_vector = Util.vectors_delta(tick_task.character.position, tick_task.target_position)
          tick_task.last_length = Util.vector_length(last_vector)
          tick_task.last_orientation = Util.vector_to_orientation(last_vector)
          tick_task.projectile.surface.create_entity{name="explosion-hit", position = Util.vectors_add(tick_task.projectile.position,{x=0,y=0})}

          if tick_task.target_is_space then
            local drone = tick_task.surface.create_entity{
              name = "grapple-on-space-drone",
              position = tick_task.projectile.position,
            }
            tick_task.projectile.destroy() -- Also destroys the line
            tick_task.projectile = drone
            draw_line(drone, tick_task.character)
          end
        else
          Grapple.destroy(tick_task)
        end
      end
    end

  else
    Grapple.destroy(tick_task)
  end

end

return Grapple
