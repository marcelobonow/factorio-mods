# waterfill

Factorio mod
 
This mod allows the placement of water just like landfill.

Research the tech to unlock.

There are 2 mod settings to allow placement over tree stumps and disable collision with items

If used with Space-Age DLC then its only useable on Nauvis and Gleba where water is actually available.

-----------
Update 2.0.3
- Added setting to allow placement over tree stumps 
- Added setting to disable collision with items (beware you could kill yourself or builds)
-----------
Update 2.0.2
- Fix Changelog and code formating
-----------
Update 2.0.1
- Added support for Alien Biomes
-----------
Update 2.0.0
- Updated for Factorio 2.0 (complete rewrite)
- Fixed so it no longers kills the player or destroys buildings
- Added support for Space-Age DLC (restricted to Nauvis and Gleba only where water is actually available)
-----------
Update 1.1.0
- Updated for Factorio 1.1
-----------
Update 0.18.0 
- Upgraded to 0.18
-----------
Update 0.17.0 
- Fixed Science packs.
- Upgraded to 0.17
- Credit go to ceryss & Riley19280 for pre 0.17 version