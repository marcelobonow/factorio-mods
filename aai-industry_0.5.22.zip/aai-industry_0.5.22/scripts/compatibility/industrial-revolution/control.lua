return {
	starting_items = require("scripts/compatibility/industrial-revolution/starting-items"),
	starting_research = require("scripts/compatibility/industrial-revolution/starting-research")
}
