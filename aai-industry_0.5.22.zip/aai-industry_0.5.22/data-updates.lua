require("prototypes/entity/entity-update")
require("prototypes/item/item-update")
if not mods.IndustrialRevolution then
    require("prototypes/recipe/recipe-update") -- IR2 handles recipe updates separately and it would be difficult to add compatibility for other big mods
    require("prototypes/technology/technology-update") -- Moved to data.lua because technologies need to have recipe unlocks before IR2 data-updates stage
end

require("prototypes/compatibility/industrial-revolution/data-updates")

--log( serpent.block( data.raw["recipe"], {comment = false, numformat = '%1.8g' } ) )
