handler = require("event_handler")
names = require("shared")
util = require("script/script_util")

handler.add_lib(require("script/construction_drone"))
handler.add_lib(require("script/freeplay_interface"))
