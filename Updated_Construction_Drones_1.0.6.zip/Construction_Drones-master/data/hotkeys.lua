local hotkeys = names.hotkeys

data:extend {
    { type = "custom-input", name = "construction-drone-toggle", key_sequence = "SHIFT + ]", consuming = "game-only" },
}
