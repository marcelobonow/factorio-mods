local require = function(name)
    return require("data/units/" .. name)
end


require("construction_drone/construction_drone")
