data.raw["beacon"]["beacon"].allowed_effects = {"consumption", "speed", "pollution","productivity"}
data.raw["beacon"]["beacon"].module_specification =
    {
      module_slots = 6,
      module_info_icon_shift = {0, 0.5},
      module_info_multi_row_initial_height_modifier = -0.3
    }

if settings.startup["more-slots"].value then
data.raw["assembling-machine"]["assembling-machine-2"].module_specification = {module_slots = 6}
data.raw["assembling-machine"]["assembling-machine-3"].module_specification = {module_slots = 8}
data.raw["assembling-machine"]["oil-refinery"].module_specification = {module_slots = 6}
data.raw["assembling-machine"]["chemical-plant"].module_specification = {module_slots = 6}
end 

-- corrects bob's modules making alien loot economy "hyper module" non-functional (auto-delete out of furnaces). Hyper module is a productivity-module, but does not have "productivity" in the name, so a name-based search skips it.
for k, v in pairs(data.raw.module) do
  if v.limitation then
    v.limitation = nil -- empty limitation table
    v.limitation_message_key = nil
  end	
end 