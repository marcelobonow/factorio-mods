data:extend(
{


{
type = "bool-setting",
name = "more-slots",
setting_type = "startup",
default_value = "false",
allowed_values = {"true", "false"},
localised_name = "Enable more Slots for Modules?",
order = "a"
},



})