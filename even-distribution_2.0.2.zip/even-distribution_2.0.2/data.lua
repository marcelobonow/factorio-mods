require("prototypes.input")
require("prototypes.technologies")
require("prototypes.icons")
require("prototypes.styles")
