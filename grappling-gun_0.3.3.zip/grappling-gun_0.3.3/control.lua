
Util = require("scripts/util") util = Util
Event = require('scripts/event')
Grapple = require('scripts/grapple')

function on_tick()
  if global.tick_tasks then
    for _, tick_task in pairs(global.tick_tasks) do
      if tick_task.type == "grappling-gun" then
        Grapple.tick_task_grappling_gun(tick_task)
      else
        tick_task.valid = false
      end
      if not tick_task.valid then
        global.tick_tasks[tick_task.id] = nil
      end
    end
  end
end
Event.addListener(defines.events.on_tick, on_tick)

function new_tick_task(type)
  global.next_tick_task_id = global.next_tick_task_id or 1
  local new_tick_task = {
    id = global.next_tick_task_id,
    valid = true,
    type = type,
    tick = game.tick
  }
  global.tick_tasks = global.tick_tasks or {}
  global.tick_tasks[new_tick_task.id] = new_tick_task
  global.next_tick_task_id = global.next_tick_task_id + 1
  return new_tick_task
end


remote.add_interface(
  "grappling-gun",
  {
    on_character_swapped = function(data)
      --[[{
          new_unit_number = new.unit_number,
          old_unit_number = old.unit_number,
          new_character = new,
          old_character = old
        }]]
      if data.new_character and data.new_character.valid and data.old_character and data.old_character.valid then
        if global.tick_tasks then
          for _, tick_task in pairs(global.tick_tasks) do
            if tick_task.type == "grappling-gun" then
              if tick_task.character and tick_task.character.valid and tick_task.character == data.old_character then
                tick_task.character = data.new_character
              end
            end
          end
        end
      end
    end,
  }
)
