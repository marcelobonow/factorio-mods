if mods["angelsindustries"] then
  if angelsmods.industries.tech then -- tech overhaul
    LSlib.technology.removeIngredient("fluid-compressor", "datacore-processing-1")
  end
end