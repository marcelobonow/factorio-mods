data:extend{
  {
    type = "recipe",
    name = "fluid-compressor",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"pump", 1},
      {"pipe", 5},
      {"assembling-machine-2", 1},
    },
    result = "fluid-compressor",
  },
}
