data:extend{
  {
    type = "recipe-category",
    name = "fluid-compressing",
  },
  {
    type = "recipe-category",
    name = "fluid-decompressing",
  },
}
