require "prototypes/fluid/compressor-fluid-updates"
require "prototypes/recipe/compressor-fluid-updates"
require "prototypes/mod-compatibility-updates"
