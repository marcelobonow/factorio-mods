require "prototypes/entity/compressor"
require "prototypes/entity/decompressor"

require "prototypes/categories/item-category"
require "prototypes/item/compressor"
require "prototypes/item/decompressor"

require "prototypes/fluid/compressor-fluid"

require "prototypes/categories/recipe-category"
require "prototypes/recipe/compressor"
require "prototypes/recipe/decompressor"

require "prototypes/technology/compressor"
require "prototypes/technology/decompressor"
