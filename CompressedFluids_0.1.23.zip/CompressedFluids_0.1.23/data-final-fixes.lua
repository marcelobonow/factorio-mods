require "prototypes/entity/compressor-final-fixes"
require "prototypes/entity/decompressor-final-fixes"

require "prototypes/fluid/compressor-fluid-final-fixes"
require "prototypes/recipe/compressor-fluid-final-fixes"

require "prototypes/mod-compatibility-final-fixes"
