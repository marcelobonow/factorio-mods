require("prototypes/entity/entity")

require("prototypes/item/item")

require("prototypes/recipe/recipe")

require("prototypes/technology/technology")

require("prototypes/signal")

require("prototypes/styles")

require("prototypes/compatibility/industrial-revolution")
