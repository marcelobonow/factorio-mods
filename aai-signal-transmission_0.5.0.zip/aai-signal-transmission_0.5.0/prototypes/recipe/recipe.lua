data:extend({
  {
    type = "recipe",
    name = "aai-signal-sender",
    ingredients = {
      {type = "item", name = "processing-unit", amount = 20},
      {type = "item", name = "battery", amount = 20},
      {type = "item", name = "steel-plate", amount = 10},
      {type = "item", name = "electric-engine-unit", amount = 10},
    },
    results = {
      {type = "item", name = "aai-signal-sender", amount = 1},
    },
    enabled = false,
    energy_required = 10,
  },
  {
    type = "recipe",
    name = "aai-signal-receiver",
    ingredients =
    {
      {type = "item", name = "processing-unit", amount = 20},
      {type = "item", name = "copper-plate", amount = 20},
      {type = "item", name = "steel-plate", amount = 20},
      {type = "item", name = "electric-engine-unit", amount = 10},
    },
    results = {
      {type = "item", name = "aai-signal-receiver", amount = 1},
    },
    enabled = false,
    energy_required = 10,
  },
})
