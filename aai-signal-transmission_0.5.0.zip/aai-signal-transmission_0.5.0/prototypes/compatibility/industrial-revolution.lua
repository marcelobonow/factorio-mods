if not mods.IndustrialRevolution then
	return
end

data.raw.technology["aai-signal-transmission"].IR_native = true
data.raw.technology["aai-signal-transmission"].prerequisites = {"circuit-network"}

data.raw.recipe["aai-signal-receiver"].energy_required = 3.2
data.raw.recipe["aai-signal-receiver"].ingredients = {
	{type = "item", name = "radar", amount = 1},
	{type = "item", name = "computer-mk2", amount = 4},
	{type = "item", name = "electric-engine-unit", amount = 8},
	{type = "item", name = "steel-plate-heavy", amount = 12},
	{type = "item", name = "steel-rod", amount = 24},
}

data.raw.recipe["aai-signal-sender"].energy_required = 3.2
data.raw.recipe["aai-signal-sender"].ingredients = {
	{type = "item", name = "steel-frame-large", amount = 1},
	{type = "item", name = "computer-mk2", amount = 4},
	{type = "item", name = "advanced-battery", amount = 20},
	{type = "item", name = "electric-engine-unit", amount = 8},
	{type = "item", name = "copper-coil", amount = 4},
}
