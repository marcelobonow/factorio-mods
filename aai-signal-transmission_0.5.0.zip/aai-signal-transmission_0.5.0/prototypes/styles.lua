local styles = data.raw["gui-style"].default

styles.aai_signal_transmission_titlebar_flow = {
  type = "horizontal_flow_style",
  horizontal_spacing = 8,
}

styles.aai_signal_transmission_titlebar_drag_handle = {
  type = "empty_widget_style",
  parent = "draggable_space",
  left_margin = 4,
  right_margin = 4,
  height = 24,
  horizontally_stretchable = "on",
}

-- Now missing this font as well
data:extend({
  {
    type = "font",
    name = "heading-3",
    from = "default-semibold",
    size = 14 -- will translate 5 modules
  },
})

styles.heading_3_label =
{
  type = "label_style",
  parent = "label",
  font = "heading-3",
  font_color = {1, 1, 1}
}

styles.aai_signal_transmission_transceiver_invisible_frame =
{
  type = "frame_style",
  parent = "invisible_frame",
  bottom_padding = 0,
  use_header_filler = false,
  header_flow_style =
  {
    type = "horizontal_flow_style",
    bottom_padding = 4,
  },
  title_style =
  {
    type = "label_style",
    parent = "heading_3_label"
  },
  horizontal_flow_style =
  {
    type = "horizontal_flow_style",
    horizontal_spacing = 0
  },
  vertical_flow_style =
  {
    type = "vertical_flow_style",
    vertical_spacing = 4,
    horizontal_align = "left"
  }
}

styles.aai_icon_selector_button =
{
  type = "button_style",
  parent = "button",
  width = 28,
  height = 28,
  padding = 0,
  top_margin = 1,
}
