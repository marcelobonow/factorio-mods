local technology =   {
  type = "technology",
  name = "aai-signal-transmission",
  effects = {
    { type = "unlock-recipe", recipe = "aai-signal-sender", },
    { type = "unlock-recipe", recipe = "aai-signal-receiver", },
  },
  icon = "__aai-signal-transmission__/graphics/technology/signal-transmission.png",
  icon_size = 256,
  order = "e-g",
  prerequisites = {
    "processing-unit",
    "electric-engine",
    "circuit-network",
  },
  unit = {
   count = 100,
   time = 30,
   ingredients = {
     { "automation-science-pack", 1 },
     { "logistic-science-pack", 1 },
     { "chemical-science-pack", 1 },
   }
  },
}


if mods["space-age"] then
  technology.prerequisites = {
    "circuit-network",
    "space-science-pack",
  }
  technology.unit.ingredients = {
    { "automation-science-pack", 1 },
    { "logistic-science-pack", 1 },
    { "chemical-science-pack", 1 },
    { "space-science-pack", 1 },
  }
end

data:extend({technology})
