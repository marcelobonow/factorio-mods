require("prototypes.recipe.updates")
require("prototypes.technology.technology-updates")
