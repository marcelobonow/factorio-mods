data:extend{
	{
		type = "double-setting",
		name = "Train-Speed-Multiplier",
		setting_type = "startup",
		default_value = 5,
		minimum_value = 0.01,
		maximum_value = 1000000
	}
}