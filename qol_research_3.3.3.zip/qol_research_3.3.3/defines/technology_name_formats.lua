return {
    player = 'qol-%s-%d-%d',
    internal = 'qolinternal-%s-%d',
}
