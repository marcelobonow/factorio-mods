local handler = require("__core__/lualib/event_handler")

handler.add_lib(require("__flib__/gui-lite"))

handler.add_lib(require("__LTN_Combinator_Modernized__/script/ltn_combinator"))
