
global.replacements = {}
