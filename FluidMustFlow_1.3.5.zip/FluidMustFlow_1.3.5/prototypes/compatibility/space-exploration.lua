if mods["space-exploration"] then
  data.raw["item"]["duct-small"].subgroup = "pipe"
  data.raw["item"]["duct"].subgroup = "pipe"
  data.raw["item"]["duct-long"].subgroup = "pipe"
  data.raw["item"]["duct-t-junction"].subgroup = "pipe"
  data.raw["item"]["duct-curve"].subgroup = "pipe"
  data.raw["item"]["duct-cross"].subgroup = "pipe"
  data.raw["item"]["duct-underground"].subgroup = "pipe"
  data.raw["item"]["non-return-duct"].subgroup = "pipe"
  data.raw["item"]["duct-end-point-intake"].subgroup = "pipe"
  data.raw["item"]["duct-end-point-outtake"].subgroup = "pipe"
end
