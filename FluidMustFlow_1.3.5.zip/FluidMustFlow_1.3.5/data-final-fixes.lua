require("prototypes.compatibility.IndustrialRevolution")
