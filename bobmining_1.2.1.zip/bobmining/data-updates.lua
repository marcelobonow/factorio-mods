require("prototypes.drill-updates")
require("prototypes.areadrill-updates")
require("prototypes.pumpjack-updates")
require("prototypes.water-miner-updates")
