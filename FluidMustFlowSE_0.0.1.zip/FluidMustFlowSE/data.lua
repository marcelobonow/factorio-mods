
data.raw["storage-tank"]["duct-small"].se_allow_in_space = true
data.raw["storage-tank"]["duct"].se_allow_in_space = true
data.raw["storage-tank"]["duct-long"].se_allow_in_space = true
data.raw["storage-tank"]["duct-t-junction"].se_allow_in_space = true
data.raw["storage-tank"]["duct-curve"].se_allow_in_space = true
data.raw["storage-tank"]["duct-cross"].se_allow_in_space = true
data.raw["pump"]["non-return-duct"].se_allow_in_space = true
data.raw["pump"]["duct-end-point-intake"].se_allow_in_space = true
data.raw["pump"]["duct-end-point-outtake"].se_allow_in_space = true
data.raw["pipe-to-ground"]["duct-underground"].se_allow_in_space = true

-- item = util.table.deepcopy(data.raw["item"]["duct-small"])
-- item.name = "space-duct-small"
-- item.place_result = "space-duct-small"

-- entity = util.table.deepcopy(data.raw["storage-tank"]["duct-small"])
-- entity.name = "space-duct-small"
-- entity.se_allow_in_space = true

-- recipe = util.table.deepcopy(data.raw["recipe"]["duct-small"])
-- recipe.name = "space-duct-small"
-- recipe.result = "space-duct-small"

-- data:extend({item, entity, recipe})

-- table.insert(data.raw["technology"]["Ducts"].effects, { type = "unlock-recipe", recipe = "space-duct-small" })

--data.raw["storage-tank"]["duct"].se_allow_in_space = true
--data.raw["pipe-to-ground"]["duct-underground"].se_allow_in_space = true
