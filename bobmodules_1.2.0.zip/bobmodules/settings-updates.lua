if mods["IndustrialRevolution"] then
  data.raw["bool-setting"]["bobmods-modules-enable-modules-lab"].hidden = true
end
