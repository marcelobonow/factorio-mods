data:extend{
    {
        type = "sprite",
        name = "informatron-example",
        filename = "__informatron__/graphics/informatron/example_image.png",
        width = 451,
        height = 400,
        flags = {"icon"},
        priority = "no-atlas"
    }
}
