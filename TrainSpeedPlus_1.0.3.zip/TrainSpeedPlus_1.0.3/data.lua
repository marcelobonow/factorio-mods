data:extend(
{
{type = "technology",name = "braking-force-8", icon_size=128 ,icon = "__base__/graphics/technology/braking-force.png",effects = { { type = "train-braking-force-bonus", modifier = 0.2 } },prerequisites = {"braking-force-7"},unit ={count =750, ingredients = { {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"production-science-pack", 1}, {"utility-science-pack", 1}}, time = 60 }, upgrade = true, order = "b-f-g"},
{type = "technology",name = "braking-force-9", icon_size=128 ,icon = "__base__/graphics/technology/braking-force.png",effects = { { type = "train-braking-force-bonus", modifier = 0.4 } },prerequisites = {"braking-force-8"},unit ={count =850, ingredients = { {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"production-science-pack", 1}, {"utility-science-pack", 1}}, time = 60 }, upgrade = true, order = "b-f-g"},
{type = "technology",name = "braking-force-10", icon_size=128 ,icon = "__base__/graphics/technology/braking-force.png",effects = { { type = "train-braking-force-bonus", modifier = 0.8 } },prerequisites = {"braking-force-9"},unit ={count =950, ingredients = { {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"production-science-pack", 1}, {"utility-science-pack", 1}}, time = 60 }, upgrade = true, order = "b-f-g"},
{type = "technology",name = "braking-force-11", icon_size=128 ,icon = "__base__/graphics/technology/braking-force.png",effects = { { type = "train-braking-force-bonus", modifier = 1.6 } },prerequisites = {"braking-force-10"},unit ={count =1050, ingredients = { {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"production-science-pack", 1}, {"utility-science-pack", 1}}, time = 60 }, upgrade = true, order = "b-f-g"},
{type = "technology",name = "braking-force-12", icon_size=128 ,icon = "__base__/graphics/technology/braking-force.png",effects = { { type = "train-braking-force-bonus", modifier = 3.2 } },prerequisites = {"braking-force-11"},unit ={count =1150, ingredients = { {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"production-science-pack", 1}, {"utility-science-pack", 1}}, time = 60 }, upgrade = true, order = "b-f-g"},
{type = "technology",name = "braking-force-13", icon_size=128 ,icon = "__base__/graphics/technology/braking-force.png",effects = { { type = "train-braking-force-bonus", modifier = 6.4 } },prerequisites = {"braking-force-12"},unit ={count =1250, ingredients = { {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"production-science-pack", 1}, {"utility-science-pack", 1}}, time = 60 }, upgrade = true, order = "b-f-g"},
{type = "technology",name = "braking-force-14", icon_size=128 ,icon = "__base__/graphics/technology/braking-force.png",effects = { { type = "train-braking-force-bonus", modifier = 12.8 } },prerequisites = {"braking-force-13"},unit ={count =1350, ingredients = { {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"production-science-pack", 1}, {"utility-science-pack", 1}}, time = 60 }, upgrade = true, order = "b-f-g"},
{type = "technology",name = "braking-force-15", icon_size=128 ,icon = "__base__/graphics/technology/braking-force.png",effects = { { type = "train-braking-force-bonus", modifier = 25.6 } },prerequisites = {"braking-force-14"},unit ={count =1450, ingredients = { {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1}, {"production-science-pack", 1}, {"utility-science-pack", 1}}, time = 60 }, upgrade = true, order = "b-f-g"},
   {
    type = "item",
    name = "enriched-rocket-fuel",
    icon = "__TrainSpeedPlus__/enriched-rocket-fuel.png",
    icon_size = 32,
	
    fuel_category = "chemical",
    fuel_value = "100GJ",
    fuel_acceleration_multiplier = 30.0,
    fuel_top_speed_multiplier = 15.0,
    subgroup = "intermediate-product",
    order = "o[rocket-fuel]",
    stack_size = 1
  },
 {
    type = "recipe",
    name = "enriched-rocket-fuel",
    energy_required = 5,
    enabled = true,
    category = "chemistry",
    ingredients = {{"uranium-fuel-cell", 1},{"rocket-fuel", 1}},
    icon = "__TrainSpeedPlus__/enriched-rocket-fuel.png",
    icon_size = 32,
    order = "i[rocket-fuel]",
    results = { { name = "enriched-rocket-fuel", amount = 5 }
    }
  }
}
)