function calculate_bonus(tiers, max_effect, penalty_start, penalty_end, function_type)
    local bonuses = {}
    local penalties = {}
    for i=1,tiers,1 do
        if function_type == "Linear" then
            bonuses[i] = (max_effect-1.0) / (tiers - 1.0) * (i-1.0) + 1
            penalties[i] = ((penalty_end - penalty_start) / (tiers - 1.0) * (i - 1.0) + penalty_start)
        end
    end
    return bonuses, penalties
end
function exponent(base, power)
    return math.exp(power * math.log(base))
end
function logarithm(base, value)
    return math.log(value) / math.log(base)
end
function get_order(tier)
    local s = tostring(tier)
    local order = ""
    if #s < 2 then order = order.."0" end
    local order = order..s
    return order
end
function get_icon_string(tier, module)
    local icon_string = ""
    if tier <= get_tiers() / 2 then
        icon_string = "__base__/graphics/icons/"..module..".png"
    elseif tier ~= get_tiers() then
        icon_string = "__base__/graphics/icons/"..module.."-2.png"
    else
        icon_string = "__base__/graphics/icons/"..module.."-3.png"
    end
    return icon_string
end
function get_cost(tier, module)
    local ingredients = {}
    if tier == 1 then
        ingredients = {{"electronic-circuit", 5},{"advanced-circuit",5}}
    else
        ingredients = {}
        local ingredients_used = 0
        local r = 1
        for i=(tier-1),1,-1 do
            r = r * get_cost_multiplier()
            if #ingredients < get_max_ingredients()-2 then
                local current = math.floor(r)
                r = r - current
                if current ~= 0 then
                    if i~=1 then
                        ingredients[#ingredients + 1] = {module.."-module-"..i,current}
                    else
                        ingredients[#ingredients + 1] = {module.."-module",current}
                    end
                end
            end
        end
        ingredients[#ingredients + 1] = {"advanced-circuit",5 + math.floor(r*5)}
        ingredients[#ingredients + 1] = {"processing-unit",5 + math.floor(r*5)}
    end
    return ingredients
end