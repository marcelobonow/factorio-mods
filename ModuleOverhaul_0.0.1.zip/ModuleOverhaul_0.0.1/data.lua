require("functions")
require("defines")

require("prototypes.item-groups")

require("prototypes.speed-modules")
require("prototypes.efficiency-modules")
require("prototypes.productivity-modules")
require("prototypes.modules")

require("prototypes.technologies")