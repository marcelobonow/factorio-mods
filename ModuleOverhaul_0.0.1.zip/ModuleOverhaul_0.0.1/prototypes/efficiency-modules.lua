function existing_efficiency(prototype)
    prototype.effect = {
        consumption = {
            bonus = -1 * get_efficiency_start() * get_bonuses()[prototype.tier] * (prototype.tier * 0.5)

        }
    }
    prototype.subgroup = "effectivity-modules"
    prototype.localised_name = {"", {"item-name.effectivity-module"}, " ", prototype.tier}
    prototype.order = get_order(prototype.tier)
    local icon_string = get_icon_string(prototype.tier, "effectivity-module")
    prototype.icon = nil
    prototype.icons = {{
        icon = icon_string,
        icon_size = 64
    }, {
        icon = "__ModuleOverhaul__/graphics/icons/" .. (get_order(prototype.tier):sub(1, 1)) .. ".png",
        icon_size = 64,
        tint = {
            r = 1,
            g = 0,
            b = 0,
            a = 1
        },
        shift = {-10, 0}
    }, {
        icon = "__ModuleOverhaul__/graphics/icons/" .. (get_order(prototype.tier):sub(2, 2)) .. ".png",
        icon_size = 64,
        tint = {
            r = 1,
            g = 0,
            b = 0,
            a = 1
        }
    }}
    if prototype.tier ~= 1 then
        data.raw.recipe["effectivity-module-" .. prototype.tier].ingredients = get_cost(prototype.tier, "effectivity")
        data.raw.recipe["effectivity-module-" .. prototype.tier].energy_required = math.floor(15 *
                                                                                                  exponent(
                get_cost_multiplier(), prototype.tier - 1))
    else
        data.raw.recipe["effectivity-module"].ingredients = get_cost(1, "effectivity")
    end
end
function new_efficiency(tier)
    local icon_string = get_icon_string(tier, "effectivity-module")
    return {
        category = "effectivity",
        effect = {
            consumption = {
                bonus = -1 * get_efficiency_start() * get_bonuses()[tier] * (tier * 0.5)
            }
        },
        tier = tier,
        icons = {{
            icon = icon_string,
            icon_size = 64
        }, {
            icon = "__ModuleOverhaul__/graphics/icons/" .. (get_order(tier):sub(1, 1)) .. ".png",
            icon_size = 64,
            tint = {
                r = 1,
                g = 0,
                b = 0,
                a = 1
            },
            shift = {-10, 0}
        }, {
            icon = "__ModuleOverhaul__/graphics/icons/" .. (get_order(tier):sub(2, 2)) .. ".png",
            icon_size = 64,
            tint = {
                r = 1,
                g = 0,
                b = 0,
                a = 1
            }
        }},
        stack_size = 50,
        name = "effectivity-module-" .. tier,
        localised_name = {"", {"item-name.effectivity-module"}, " ", tier},
        type = "module",
        subgroup = "effectivity-modules",
        order = get_order(tier),
        localised_description = {"item-description.effectivity-module"}

    }, {
        ingredients = get_cost(tier, "effectivity"),
        result = "effectivity-module-" .. tier,
        name = "effectivity-module-" .. tier,
        localised_name = {"", {"item-name.effectivity-module"}, " ", tier},
        type = "recipe",
        order = get_order(tier),
        energy_required = math.floor(15 * exponent(get_cost_multiplier(), tier - 1)),
        enabled = false
    }
end
