function existing_speed(prototype)
    prototype.effect = {
        speed = {bonus = get_speed_start() * get_bonuses()[prototype.tier]},
        consumption = {bonus = get_speed_start() * get_bonuses()[prototype.tier] * get_penalties()[prototype.tier]}
    }
    prototype.subgroup = "speed-modules"
    prototype.localised_name = {"", {"item-name.speed-module"}, " ", prototype.tier}
    prototype.order = get_order(prototype.tier)
    local icon_string = get_icon_string(prototype.tier, "speed-module")
    prototype.icon = nil
    prototype.icons = {
        {icon = icon_string, icon_size = 64},
        {icon = "__ModuleOverhaul__/graphics/icons/"..(get_order(prototype.tier):sub(1,1))..".png", icon_size = 64, tint = {r=1,g=0,b=0,a=1},shift={-10,0}},
        {icon = "__ModuleOverhaul__/graphics/icons/"..(get_order(prototype.tier):sub(2,2))..".png", icon_size = 64, tint = {r=1,g=0,b=0,a=1}}
    }
    if prototype.tier ~= 1 then
        data.raw.recipe["speed-module-"..prototype.tier].ingredients = get_cost(prototype.tier,"speed")
        data.raw.recipe["speed-module-"..prototype.tier].energy_required = math.floor(15 * exponent(get_cost_multiplier(),prototype.tier-1))
    else
        data.raw.recipe["speed-module"].ingredients = get_cost(1, "speed")
    end
end
function new_speed(tier)
    local icon_string = get_icon_string(tier, "speed-module")
    return {
        category = "speed",
        effect = {
            speed = {bonus = get_speed_start() * get_bonuses()[tier]},
            consumption = {bonus = get_speed_start() * get_bonuses()[tier] * get_penalties()[tier]}
        },
        tier = tier,
        icons = {
            {icon = icon_string, icon_size = 64},
            {icon = "__ModuleOverhaul__/graphics/icons/"..(get_order(tier):sub(1,1))..".png", icon_size = 64, tint = {r=1,g=0,b=0,a=1},shift={-10,0}},
            {icon = "__ModuleOverhaul__/graphics/icons/"..(get_order(tier):sub(2,2))..".png", icon_size = 64, tint = {r=1,g=0,b=0,a=1}}
        },
        stack_size = 50,
        name = "speed-module-"..tier,
        localised_name = {"", {"item-name.speed-module"}, " ", tier},
        type = "module",
        subgroup = "speed-modules",
        order = get_order(tier),
        localised_description = {"item-description.speed-module"}

    },
    {
        ingredients = get_cost(tier, "speed"),
        result = "speed-module-"..tier,
        name = "speed-module-"..tier,
        localised_name = {"", {"item-name.speed-module"}, " ", tier},
        type = "recipe",
        order = get_order(tier),
        energy_required = math.floor(15 * exponent(get_cost_multiplier(),tier-1)),
        enabled = false
    }
end