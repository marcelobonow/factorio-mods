function existing_productivity(prototype)
    prototype.effect = {
        speed = {bonus = -1 * get_productivity_start() * get_bonuses()[prototype.tier] * get_penalties()[prototype.tier]},
        consumption = {bonus = get_productivity_consumption_multiplier() * get_productivity_start() * get_bonuses()[prototype.tier] * get_penalties()[prototype.tier]},
        pollution = {bonus = get_productivity_start() * get_bonuses()[prototype.tier] * get_penalties()[prototype.tier]},
        productivity = {bonus = get_productivity_start() * get_bonuses()[prototype.tier]}
    }
    prototype.subgroup = "productivity-modules"
    prototype.localised_name = {"", {"item-name.productivity-module"}, " ", prototype.tier}
    prototype.order = get_order(prototype.tier)
    local icon_string = get_icon_string(prototype.tier, "productivity-module")
    prototype.icon = nil
    prototype.icons = {
        {icon = icon_string, icon_size = 64},
        {icon = "__ModuleOverhaul__/graphics/icons/"..(get_order(prototype.tier):sub(1,1))..".png", icon_size = 64, tint = {r=1,g=0,b=0,a=1},shift={-10,0}},
        {icon = "__ModuleOverhaul__/graphics/icons/"..(get_order(prototype.tier):sub(2,2))..".png", icon_size = 64, tint = {r=1,g=0,b=0,a=1}}
    }
    if prototype.tier ~= 1 then
        data.raw.recipe["productivity-module-"..prototype.tier].ingredients = get_cost(prototype.tier, "productivity")
        data.raw.recipe["speed-module-"..prototype.tier].energy_required = math.floor(15 * exponent(get_cost_multiplier(),prototype.tier-1))
    else
        data.raw.recipe["productivity-module"].ingredients = get_cost(1, "productivity")
    end
end
function new_productivity(tier)
    local icon_string = get_icon_string(tier, "productivity-module")
    return {
        category = "productivity",
        effect = {
            speed = {bonus = -1 * get_productivity_start() * get_bonuses()[tier] * get_penalties()[tier]},
            consumption = {bonus = get_productivity_consumption_multiplier() * get_productivity_start() * get_bonuses()[tier] * get_penalties()[tier]},
            pollution = {bonus = get_productivity_start() * get_bonuses()[tier] * get_penalties()[tier]},
            productivity = {bonus = get_productivity_start() * get_bonuses()[tier]}
        },
        tier = tier,
        icons = {
            {icon = icon_string, icon_size = 64},
            {icon = "__ModuleOverhaul__/graphics/icons/"..(get_order(tier):sub(1,1))..".png", icon_size = 64, tint = {r=1,g=0,b=0,a=1},shift={-10,0}},
            {icon = "__ModuleOverhaul__/graphics/icons/"..(get_order(tier):sub(2,2))..".png", icon_size = 64, tint = {r=1,g=0,b=0,a=1}}
        },
        stack_size = 50,
        name = "productivity-module-"..tier,
        localised_name = {"", {"item-name.speed-module"}, " ", tier},
        type = "module",
        subgroup = "productivity-modules",
        order = get_order(tier),
        localised_description = {"item-description.productivity-module"}

    },
    {
        ingredients = get_cost(tier, "productivity"),
        result = "productivity-module-"..tier,
        name = "productivity-module-"..tier,
        localised_name = {"", {"item-name.productivity-module"}, " ", tier},
        type = "recipe",
        order = get_order(tier),
        energy_required = math.floor(15 * exponent(get_cost_multiplier(),tier-1)),
        enabled = false
    }
end