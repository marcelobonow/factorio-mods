settings = {
    {
        name = "num-tiers",
        type = "int-setting",
        order = "1-0",
        default_value = 10,
        minimum_value = 3,
        maximum_value = 50,
        setting_type = "startup"
    },
    {
        name = "max-effect",
        type = "double-setting",
        order = "1-1",
        default_value = 4,
        minimum_value = 1.1,
        maximum_value = 100,
        setting_type = "startup"

    },
    {
        name = "function-type",
        type = "string-setting",
        order = "1-9",
        default_value = "Linear",
        allowed_values = {"Linear"},
        setting_type = "startup"
    },
    {
        name = "cost-multiplier",
        type = "double-setting",
        order = "2-1",
        default_value = 1.5,
        minimum_value = 1.1,
        maximum_value = 10,
        setting_type = "startup"
    },
    {
        name = "first-tier-penalty-multiplier",
        type = "double-setting",
        order = "1-2",
        default_value = 3,
        minimum_value = 1,
        maximum_value = 100,
        setting_type = "startup"
    },
    {
        name = "final-tier-penalty-multiplier",
        type = "double-setting",
        order = "1-3",
        default_value = 1.5,
        minimum_value = 0,
        maximum_value = 100,
        setting_type = "startup"
    },
    {
        name = "max-ingredients",
        type = "int-setting",
        order = "2-2",
        default_value = 6,
        minimum_value = 2,
        maximum_value = 48,
        setting_type = "startup"
    },
    {
        name = "productivity-consumption-multiplier",
        type = "double-setting",
        order = "3-4",
        default_value = 3,
        minimum_value = 1,
        maximum_value = 100,
        setting_type = "startup"
    }
}
local settings_data = {{"speed","efficiency","productivity"},{0.2, 0.3, 0.04}}
for i=1,3,1 do
    settings[#settings + 1] = {
        name = settings_data[1][i].."-module-start-bonus",
        type = "double-setting",
        order = "3-"..i,
        default_value = settings_data[2][i],
        minimum_value = 0.01,
        maximum_value = 10,
        setting_type = "startup"
    }
end
data:extend(settings)