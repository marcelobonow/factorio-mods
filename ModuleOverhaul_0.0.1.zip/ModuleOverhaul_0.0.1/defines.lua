module_overhaul_mod = true
local tiers = settings.startup["num-tiers"].value
local max_effect = settings.startup["max-effect"].value
local cost_multiplier = settings.startup["cost-multiplier"].value
local function_type = settings.startup["function-type"].value
local penalty_start = settings.startup["first-tier-penalty-multiplier"].value
local penalty_end = settings.startup["final-tier-penalty-multiplier"].value
local speed_start = settings.startup["speed-module-start-bonus"].value
local efficiency_start = settings.startup["efficiency-module-start-bonus"].value
local productivity_start = settings.startup["productivity-module-start-bonus"].value
local productivity_consumption_multiplier = settings.startup["productivity-consumption-multiplier"].value
local max_ingredients = settings.startup["max-ingredients"].value
local module_types = {"speed-module","efficiency-module","productivity-module"}
local bonuses, penalties = calculate_bonus(tiers, max_effect, penalty_start, penalty_end, function_type)

function get_tiers()
    return tiers
end
function get_max_effect()
    return max_effect
end
function get_cost_multiplier()
    return cost_multiplier
end
function get_function_type()
    return function_type
end
function get_penalty_start()
    return penalty_start
end
function get_penalty_end()
    return penalty_end
end
function get_speed_start()
    return speed_start
end
function get_efficiency_start()
    return efficiency_start
end
function get_productivity_start()
    return productivity_start
end
function get_module_types()
    return module_types
end
function get_bonuses()
    return bonuses
end
function get_penalties()
    return penalties
end
function get_max_ingredients()
    return max_ingredients
end
function get_productivity_consumption_multiplier()
    return productivity_consumption_multiplier
end